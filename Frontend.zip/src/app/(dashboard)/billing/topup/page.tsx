'use client';

import { useState } from 'react';
import { apiFetch } from '@/lib/api-client';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ErrorAlert } from '@/components/ui/error-alert';
import { Field } from '@/components/ui/field';
import { Input } from '@/components/ui/input';
import { JsonBlock } from '@/components/ui/json-block';
import { PageHeader } from '@/components/ui/page-header';

export default function BillingTopupPage() {
  const [amountRub, setAmountRub] = useState('100');
  const [creating, setCreating] = useState(false);
  const [errorText, setErrorText] = useState('');
  const [result, setResult] = useState<unknown>(null);

  async function handleCreate() {
    setCreating(true);
    setErrorText('');

    try {
      const amount = Number(amountRub);
      const payload = {
        amountRub: Number.isFinite(amount) ? amount : undefined,
        amountMinor: Number.isFinite(amount) ? Math.round(amount * 100) : undefined,
      };

      const response = await apiFetch('/payments/create', {
        method: 'POST',
        auth: true,
        body: JSON.stringify(payload),
      });

      setResult(response);
    } catch (error) {
      setErrorText(error instanceof Error ? error.message : 'Не удалось создать платёж');
    } finally {
      setCreating(false);
    }
  }

  const redirectUrl =
    result && typeof result === 'object'
      ? (result as Record<string, unknown>).redirectUrl ?? (result as Record<string, unknown>).paymentUrl
      : null;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Пополнение баланса"
        description="Создание платежа на пополнение. Если backend вернёт redirect URL провайдера, он появится ниже."
      />

      {errorText ? <ErrorAlert text={errorText} /> : null}

      <Card>
        <div className="grid gap-4 md:grid-cols-[minmax(0,1fr)_auto] md:items-end">
          <Field label="Сумма, ₽">
            <Input
              type="number"
              min="1"
              step="0.01"
              value={amountRub}
              onChange={(event) => setAmountRub(event.target.value)}
            />
          </Field>

          <Button onClick={handleCreate} disabled={creating}>
            {creating ? 'Создаём платёж...' : 'Создать платёж'}
          </Button>
        </div>

        {redirectUrl && typeof redirectUrl === 'string' ? (
          <div className="mt-5 rounded-2xl border border-emerald-400/20 bg-emerald-500/10 p-4">
            <div className="text-sm text-emerald-100">
              Backend вернул ссылку оплаты:
            </div>
            <a
              href={redirectUrl}
              target="_blank"
              rel="noreferrer"
              className="mt-2 inline-flex rounded-2xl bg-emerald-400 px-4 py-2 text-sm font-medium text-slate-950"
            >
              Открыть страницу оплаты
            </a>
          </div>
        ) : null}
      </Card>

      {result ? (
        <Card>
          <JsonBlock title="Ответ create payment" data={result} />
        </Card>
      ) : null}
    </div>
  );
}
