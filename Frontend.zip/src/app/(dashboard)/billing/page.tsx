'use client';

import { useEffect, useState } from 'react';
import { apiFetch } from '@/lib/api-client';
import { toArray } from '@/lib/data';
import { formatMinorToRub, formatRubles } from '@/lib/format';
import { Card } from '@/components/ui/card';
import { DataTable } from '@/components/ui/data-table';
import { EmptyState } from '@/components/ui/empty-state';
import { ErrorAlert } from '@/components/ui/error-alert';
import { JsonBlock } from '@/components/ui/json-block';
import { PageHeader } from '@/components/ui/page-header';
import { StatCard } from '@/components/ui/stat-card';

export default function BillingPage() {
  const [balance, setBalance] = useState<unknown>(null);
  const [ledger, setLedger] = useState<unknown>(null);
  const [loading, setLoading] = useState(true);
  const [errorText, setErrorText] = useState('');

  useEffect(() => {
    let cancelled = false;

    async function load() {
      try {
        setLoading(true);
        setErrorText('');

        const [balanceRes, ledgerRes] = await Promise.all([
          apiFetch('/billing/balance', { method: 'GET', auth: true }),
          apiFetch('/billing/ledger?take=50', { method: 'GET', auth: true }),
        ]);

        if (!cancelled) {
          setBalance(balanceRes);
          setLedger(ledgerRes);
        }
      } catch (error) {
        if (!cancelled) {
          setErrorText(error instanceof Error ? error.message : 'Не удалось загрузить billing');
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    void load();

    return () => {
      cancelled = true;
    };
  }, []);

  const balanceRecord = balance && typeof balance === 'object' ? balance as Record<string, unknown> : null;

  const balanceText =
    typeof balanceRecord?.balanceRub === 'number'
      ? formatRubles(balanceRecord.balanceRub)
      : typeof balanceRecord?.amountRub === 'number'
        ? formatRubles(balanceRecord.amountRub)
        : typeof balanceRecord?.balanceMinor === 'number'
          ? formatMinorToRub(balanceRecord.balanceMinor)
          : typeof balanceRecord?.amountMinor === 'number'
            ? formatMinorToRub(balanceRecord.amountMinor)
            : '—';

  const ledgerRows = toArray<Record<string, unknown>>(ledger).map((entry) => ({
    id: String(entry.id ?? ''),
    type: String(entry.type ?? entry.operationType ?? '—'),
    amount:
      typeof entry.amountMinor === 'number'
        ? formatMinorToRub(entry.amountMinor)
        : typeof entry.deltaMinor === 'number'
          ? formatMinorToRub(entry.deltaMinor)
          : '—',
    description: String(entry.description ?? entry.reason ?? '—'),
    createdAt: String(entry.createdAt ?? '—'),
  }));

  return (
    <div className="space-y-6">
      <PageHeader
        title="Баланс и ledger"
        description="Баланс пользователя и журнал движений кошелька. Все запросы идут по JWT через /v1/billing/*."
      />

      {errorText ? <ErrorAlert text={errorText} /> : null}

      <div className="grid gap-4 md:grid-cols-2">
        <StatCard label="Текущий баланс" value={loading ? '...' : balanceText} />
        <StatCard label="Записей в ledger" value={loading ? '...' : String(ledgerRows.length)} />
      </div>

      {ledgerRows.length ? (
        <Card>
          <div className="mb-4 text-lg font-semibold text-white">История движений</div>
          <DataTable rows={ledgerRows} preferredColumns={['id', 'type', 'amount', 'description', 'createdAt']} />
        </Card>
      ) : (
        !loading && <EmptyState title="Движений пока нет" />
      )}

      {balance ? (
        <Card>
          <JsonBlock title="Raw balance response" data={balance} />
        </Card>
      ) : null}

      {ledger ? (
        <Card>
          <JsonBlock title="Raw ledger response" data={ledger} />
        </Card>
      ) : null}
    </div>
  );
}
